codes = {"1":"02 00", "2":"03 00", "3":"04 00", "4":"05 00", "5":"06 00", "6":"07 00", "7":"08 00", "8":"09 00",
         "9":"0A 00", "0":"0B 00", "-":"0C 00", "=":"0D 00", "backspace":"0E 00", "tab":"0F 00", "q":"10 00",
         "w":"11 00", "e":"12 00", "r":"13 00", "t":"14 00", "y":"15 00", "u":"16 00", "i":"17 00", "o":"18 00",
         "p":"19 00", "[":"1A 00", "]":"1B 00", "capslock":"3A 00", "a":"1E 00", "s":"1F 00", "d":"20 00",
         "f":"21 00", "g":"22 00", "h":"23 00", "j":"24 00", "k":"25 00", "l":"26 00", ";":"27 00", "'":"28 00",
         "\ ":"2B 00", "enter":"1C 00", "lshift":"2A 00", "`":"29 00", "z":"2C 00", "x":"2D 00", "c":"2E 00",
         "v":"2F 00", "b":"30 00", "n":"31 00", "m":"32 00", ",":"33 00", ".":"34 00", "/":"35 00", "rshift":"36 00",
         "lctrl":"1D 00", "lalt":"38 00", "lwin":"5B E0", "space":"39 00", "rwin":"5C E0", "ralt":"38 E0",
         "rctrl":"1D E0", "esc":"01 00", "f1":"3B 00", "f2":"3C 00", "f3":"3D 00", "f4":"3E 00", "f5":"3F 00",
         "f6":"40 00", "f7":"41 00", "f8":"42 00", "f9":"43 00", "f10":"44 00", "f11":"57 00", "f12":"58 00"}

count = 1
result = " 00 00 00 00 00 00 00 00 count 00 00 00 "
while True:
    firstKey = str(input('Кнопка, которую заменить: '))
    if firstKey == "":
        break
    try:
        firstCode = codes[firstKey]
    except:
        print('Такая кнопка не найдена')
        continue
    secondKey = str(input('Кнопка, на которую заменить: '))
    try:
        secondCode = codes[secondKey] if secondKey != "" else "00 00"
    except:
        print('Такая кнопка не найдена')
        continue
    count += 1
    result += f"{secondCode} {firstCode} "
    print(f"{firstKey} -> {secondKey}")

result += "00 00 00 00"
if count <= 9:
    result = result.replace("count", f"0{count}")
else:
    result = result.replace("count", str(count))
print(result[1:])
print(result.replace(' ', ', 0x')[2:])
